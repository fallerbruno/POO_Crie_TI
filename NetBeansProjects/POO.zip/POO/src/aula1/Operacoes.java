package aula1;

/**
 *
 * @author faller
 */
public class Operacoes {
    
    public static int somar( int var1, int var2){
        int resultado = var1+var2;
        return resultado;
    }
      public static int subtrair(int var1, int var2){
        int resultado = var1-var2;
        return resultado;
    }
}
